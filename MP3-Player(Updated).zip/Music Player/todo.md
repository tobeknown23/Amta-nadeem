﻿Todo:

> Clean Code
> Separate functions
> Interface changes
> <s>Fix saving of playlists</s>
> <s>Fix loading of playlists</s>
> General refactoring of code