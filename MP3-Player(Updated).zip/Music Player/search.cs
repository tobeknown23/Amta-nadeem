﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Music_Player
{
    class search
    {
        //by amta
        //for seraching the songs in the playlist //
        public void songs(TextBox s,ListBox lb,ListBox playlist)
        {
            lb.Items.Clear();
           
           
                if (playlist.SelectedItem.ToString() == s.Text)
                {
                    lb.Items.Add(s.Text);
                }
                else
                {
                    MessageBox.Show("not found");
                }
                
            }
            }


           
        }
    

