﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Music_Player {
    class MusicPlayer {
        //by amta



        //importing the extension of windows media player dll files //
        [DllImport("winmm.dll")]
    
        private static extern long mciSendString(string lpstrCommand, StringBuilder lpstrReturnString, int uReturnLength, int hwdCallBack);


        //for volume//
		[DllImport("winmm.dll")]
		public static extern long waveOutSetVolume(IntPtr hwo, out uint dwVolume);

		[DllImport("winmm.dll")]
		public static extern long waveOutGetVolume(IntPtr hwo, uint dwVolume);

        //to open the file//
        public void open(string File) {
           // string command = $"open \"{file}\" type MPEGVideo alias MyMp3";
            string Format = @"open ""{0}"" type MPEGVideo alias MediaFile";
            string command = string.Format(Format, File);
            mciSendString(command, null, 0, 0);
        }
        //to play the file//
        public void play() {
            string command = "play MediaFile";
            mciSendString(command, null, 0, 0);
           // string command = "play MyMp3";
            //mciSendString(command, null, 0, 0);
        }
        //to stop the file//
        public void stop() {
            string command = "stop MediaFile";
            mciSendString(command, null, 0, 0);
         //   string command = "stop MyMp3";
          //  mciSendString(command, null, 0, 0);


            //close the mp3 player
            command = "close MyMp3";
            mciSendString(command, null, 0, 0);
        }
        //pause the song
        public void pause() {
            string command = "pause MediaFile";
            mciSendString(command, null, 0, 0);
        }

        //for volume maximam //
		public int Volume {
			get {

				uint CurrVol = 0;
				waveOutGetVolume(IntPtr.Zero, CurrVol);
				ushort CalcVol = (ushort)(CurrVol & 0x0000ffff);
				return CalcVol / (ushort.MaxValue / 100);
			}
			set {
				if (value < 0 || value > 100)
					throw new ArgumentOutOfRangeException();
				int NewVolume = ((ushort.MaxValue / 100) * value);
				uint NewVolumeAllChannels = (((uint)NewVolume & 0x0000ffff) | ((uint)NewVolume << 16));
				Console.WriteLine(waveOutSetVolume(IntPtr.Zero, out NewVolumeAllChannels));
			}
		}
	}
}