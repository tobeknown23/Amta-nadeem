﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music_Player
{
    class updatevideo
    {
        //by amta

        //addmin windows video player
        public string FileName { get; set; }


        public string Path {get;  set; }
    }
}
